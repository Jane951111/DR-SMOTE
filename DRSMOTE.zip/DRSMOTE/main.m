clear
clc
load("image_data.mat");
load("image_label.mat");
%remove label which has only one instance
index_num1=[];
for j=1:size(label,2)
    [num,~]=size(find(label(:,j)==1));
    if num==1||num==0
        index_num1=[index_num1,j];
    end
end
label(:,index_num1)=[];

classifier=1; %1:BR-tree,2:MLKNN,3:CC
iteration=20;
K=5;
for j=1:iteration
    indices = crossvalind('Kfold',size(data,1),K);
    for i = 1:K
        j
        i
        test_pos = (indices == i);
        train_pos = ~test_pos;   %�ֱ�ȡ��1��2��...��i��Ϊ���Լ�������Ϊѵ����
        test_X=data(test_pos,:);
        test_Y=label(test_pos,:);
        train_X=data(train_pos,:);
        train_Y=label(train_pos,:);

        
        for jj=1:size(train_Y,2)
            tempsum=sum(train_Y(:,jj));
            if tempsum==0
                [tem_index,~]=find(test_Y(:,jj)==1);
                changeindex=randperm(size(train_X,1));
                changeindex(:,2:end)=[];
                tem_x=train_X(changeindex,:);
                tem_y=train_Y(changeindex,:);
                train_X(changeindex,:)=test_X(tem_index(1),:);
                train_Y(changeindex,:)=test_Y(tem_index(1),:);
                test_X(tem_index(1),:)=tem_x;
                test_Y(tem_index(1),:)=tem_y;
            end
        end
        
         newMacF1(i,:)=DRSMOTE(train_X,train_Y,test_X,test_Y,classifier);

    end
    
%new
   newmaF1(j,:)=mean(newMacF1); 

end

   %new
   finalnewmaF1=mean(newmaF1);
 