function [dist_adHamming] = adHammingdistance(candidate_x,candidate_y,train_X1,train_Y,k)

for i=1:size(candidate_x,1)
    %find k-nearest neighbors
    [mIdx,~] = knnsearch(train_X1,candidate_x(i,:),'K',k+1,'Distance','Euclidean');
    mIdx=mIdx(:,2:end);
    neighbor_y=train_Y(mIdx,:);

    %计算样本和近邻样本标签的调整后的汉明距离=两个候选样本标签集合中相应位置标签不同的个数/相关标签的数量：标签总个数-两个标签集中标签都为0的个数。
    for j=1:k
        [~,num_differ]=size(find(candidate_y(i,:)~=neighbor_y(j,:)));
        [~,num_all0]=size(find((candidate_y(i,:)==0)&(neighbor_y(j,:)==0)));
        dist_hamming(i,j)=num_differ/(size(candidate_y,2)-num_all0);
    end
    dist_adHamming(i,:)=sum(dist_hamming(i,:))/k;
end

end
    