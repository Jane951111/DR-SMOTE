function MacF1=DRSMOTE(train_X,train_Y,test_X,test_Y,classifier)
k=5; %the number of nearest neighbors
parameter=0.8;


[IRLbl,MeanIR]=calculateMeanIRandIRLbl(train_Y);

%resort the labels according to IRLbl: it is used to loop
[~,label_index]=sort(IRLbl,'descend');

currentMeanIR=MeanIR;
newtrain_Y=train_Y;
newtrain_X=train_X;


%loop
for j=1:size(train_Y,2)
    if  IRLbl(label_index(j))~=inf && IRLbl(label_index(j))>MeanIR
        candidate_index=find(train_Y(:,label_index(j))==1);
        candidate_x=train_X(candidate_index,:);
        candidate_y=train_Y(candidate_index,:);
     

        %calculate adjustHamming distance for candidate
        [dist_adHamming]=adHammingdistance(candidate_x,candidate_y,newtrain_X,newtrain_Y,k);
         
        %generate examples
        for i=1:size(dist_adHamming,1)
            index_temp=i;
            if dist_adHamming(index_temp,:)<parameter
                [newexample_x,newexample_y]=examplegenerate(candidate_x,candidate_y,index_temp,newtrain_X,newtrain_Y);
                    newMIRset=[newtrain_Y;newexample_y];
                    [~,newMeanIR]=calculateMeanIRandIRLbl(newMIRset);
                    if newMeanIR<currentMeanIR 
                        newtrain_X=[newtrain_X;newexample_x];
                        newtrain_Y=[newtrain_Y;newexample_y];
                        currentMeanIR=newMeanIR;
                    end
            end
        end
    end
end


remove_index=[];
for i=1:size(newtrain_X,1)
    sample_x=newtrain_X(i,:);
    sample_y=newtrain_Y(i,:);
    adjustedHammDist=adHammingdistance(sample_x,sample_y,newtrain_X,newtrain_Y,k);
    
    if adjustedHammDist>=parameter 
        remove_index=[remove_index;i];
    end
end

%make for removing
newtrain_X(remove_index,:)=[];
newtrain_Y(remove_index,:)=[];


%change label 0 to -1 for performance evaluation
newtrain_Y(newtrain_Y==0)=-1;
test_Y(test_Y==0)=-1;

if classifier==1
    [MacF1, MicF1]=BR(newtrain_X,newtrain_Y,test_X,test_Y);
elseif classifier==2
    %train a classifer     
    %Set parameters for the MLKNN algorithm
    Num=10;
    Smooth=1; % Set the number of nearest neighbors considered to 10 and the smoothing parameter to 1

    % Calling the main functions
    [Prior,PriorN,Cond,CondN]=MLKNN_train(newtrain_X,newtrain_Y',Num,Smooth); % Invoking the training procedure
    [~,~, MacF1, MicF1]=MLKNN_test(newtrain_X,newtrain_Y',test_X,test_Y',Num,Prior,PriorN,Cond,CondN); % Performing the test procedure
elseif classifier==3
    [MacF1, MicF1]=CC(newtrain_X,newtrain_Y,test_X,test_Y);
end


end

