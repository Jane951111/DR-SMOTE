function [newexample_x,newexample_y]=examplegenerate(candidate_x,candidate_y,index_temp,train_X,train_Y)
sample_x=candidate_x(index_temp,:);
sample_y=candidate_y(index_temp,:);
for i=1:size(train_X,1)
    dist(i,:)=pdist2(sample_x,train_X(i,:));
end

[dist_value,dist_index]=sort(dist,'ascend');
for i=1:size(dist_index,1)
    temp=dist_index(i,:);
    [~,num_differ]=size(find(sample_y~=train_Y(temp,:)));
    [~,num_all0]=size(find((sample_y==0)&(train_Y(temp,:)==0)));
    dist_hamming=num_differ/(size(candidate_y,2)-num_all0);
    if dist_hamming>0
        temp_dist=dist_value(i,:);
        if temp_dist==0
            continue;
        else
            break;
        end
    end
end

randnum=abs(normrnd(0,1/3));
while randnum>=1
    randnum=abs(normrnd(0,1/3));
end
dist_sash=randnum*temp_dist;

%reorder the features
num_feature=size(sample_x,2);
reorder_index=randperm(num_feature);
for i=1:(num_feature-1)
    move_x=(rand(1)*2-1)*dist_sash;
    shadow_x(:,reorder_index(i))=sample_x(:,reorder_index(i))+move_x;
    dist_sash=sqrt(dist_sash^2-move_x^2);
end
shadow_x(:,reorder_index(end))=sample_x(:,reorder_index(end))+dist_sash;    

newexample_x=shadow_x;
newexample_y=sample_y;
    
end