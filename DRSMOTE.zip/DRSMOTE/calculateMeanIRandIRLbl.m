function [IRLbl,MeanIR] = calculateMeanIRandIRLbl(train_Y)
IRLbl=max(sum(train_Y))./sum(train_Y);
MeanIR=mean(IRLbl);
end
    