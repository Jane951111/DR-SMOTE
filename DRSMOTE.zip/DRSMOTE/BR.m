function [MacF1, MicF1]=BR(train_data,train_target,test_data,test_target)
Outputs=zeros(size(test_target,1),size(test_target,2));
Pre_Labels=zeros(size(test_target,1),size(test_target,2));
for j=1:size(train_target,2)
    target=train_target(:,j);
    tree=fitctree(train_data,target);
    [Pre_Labels(:,j),temp_Outputs]=predict(tree,test_data);
    Outputs(:,j)=max(temp_Outputs');
end


MacF1 = MacroF1(Pre_Labels',test_target');
MicF1 = MicroF1(Pre_Labels',test_target');
end
